<?php

declare(strict_types = 1);

define('STORAGE_PATH', __DIR__ . '/../storage');
define('VIEW_PATH', __DIR__ . '/../views');
define('CONFIG_PATH', __DIR__ . '/../configs');
