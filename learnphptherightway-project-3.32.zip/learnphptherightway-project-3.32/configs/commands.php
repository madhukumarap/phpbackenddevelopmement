<?php

declare(strict_types = 1);

use App\Commands\MyCommand;

return [
    MyCommand::class,
];
