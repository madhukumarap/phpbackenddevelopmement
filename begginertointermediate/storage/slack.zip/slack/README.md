
Slack
===============

(Define the functionality of your block)

How it works
============

(1) Download the plugin and unpack zip file to /blocks directory.

(2) Go to Site administration > Notifications to complete the plugin installation.
